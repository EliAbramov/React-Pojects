import React from 'react'

const styleHeader = {
    color: "Snow",
    fontSize: "3.5rem",
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
}

export default function Header() {
    return (
        <div>
           <h1 style={styleHeader}>Love Me</h1> 
        </div>
    )
}


