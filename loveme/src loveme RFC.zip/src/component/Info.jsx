import React from 'react'

export default function Info(props) {
    return (
        <div>
            <p>{props.info}</p>
        </div>
    )
}
