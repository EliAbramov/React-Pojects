import React from 'react'

export default function About() {
    return (
        <div>
            <h2>About</h2>
            <p>This is about page</p>
        </div>
    )
}
