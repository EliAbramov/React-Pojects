import React from 'react'

export default function Contact() {
    return (
        <div>
            <h2>Contact us: never</h2>
            <p>Tel: +123 55588_233</p>
            <p>Mail: nevermailhere@nomail.com</p>
        </div>
    )
}
