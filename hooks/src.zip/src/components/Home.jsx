import React from 'react'

export default function Home() {
    return (
        <div>
            <h2>Welcome to PTP</h2>
            <p>Site for person to person</p>
        </div>
    )
}
