import React, {useState} from 'react'

export default function Product(props) {

    const [roomIndex, setRoomIndex] = useState(props.roomIndex)
    const [productIndex, setProductIndex] = useState(props.productIndex)
    
    return (
        <button 
            onClick={()=>{props.changeColor(roomIndex, productIndex)}} 
            className="product" 
            style={{backgroundColor: props.color}}
        >
            {props.productName}
        </button>
    )
}
